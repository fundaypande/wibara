


<!-- jquery
============================================ -->
<script src="{!! asset('js/admin/vendor/jquery-1.12.4.min.js') !!}"></script>
<!-- bootstrap JS
============================================ -->
<script src="{!! asset('js/admin/bootstrap.min.js') !!}"></script>
<!-- wow JS
============================================ -->
<script src="{!! asset('js/admin/wow.min.js') !!}"></script>
<!-- price-slider JS
============================================ -->
<script src="{!! asset('js/admin/jquery-price-slider.js') !!}"></script>
<!-- meanmenu JS
============================================ -->
<script src="{!! asset('js/admin/jquery.meanmenu.js') !!}"></script>
<!-- owl.carousel JS
============================================ -->
<script src="{!! asset('js/admin/owl.carousel.min.js') !!}"></script>
<!-- sticky JS
============================================ -->
<script src="{!! asset('js/admin/jquery.sticky.js') !!}"></script>
<!-- scrollUp JS
============================================ -->
<script src="{!! asset('js/admin/jquery.scrollUp.min.js') !!}"></script>
<!-- counterup JS
============================================ -->
<script src="{!! asset('js/admin/counterup/jquery.counterup.min.js') !!}"></script>
<script src="{!! asset('js/admin/counterup/waypoints.min.js') !!}"></script>
<script src="{!! asset('js/admin/counterup/counterup-active.js') !!}"></script>
<!-- mCustomScrollbar JS
============================================ -->
<script src="{!! asset('js/admin/scrollbar/jquery.mCustomScrollbar.concat.min.js') !!}"></script>
<script src="{!! asset('js/admin/scrollbar/mCustomScrollbar-active.js') !!}"></script>
<!-- metisMenu JS
============================================ -->
<script src="{!! asset('js/admin/metisMenu/metisMenu.min.js') !!}"></script>
<script src="{!! asset('js/admin/metisMenu/metisMenu-active.js') !!}"></script>

<!-- plugins JS
============================================ -->
<script src="{!! asset('js/admin/plugins.js') !!}"></script>
<!-- main JS
============================================ -->
<script src="{!! asset('js/admin/main.js') !!}"></script>
<!-- tawk chat JS
============================================ -->


<!-- Datatables -->
<!-- <script src="{!! asset('assets/datatables/js/dataTables.bootstrap.min.js') !!}"></script> -->

<script src="{!! asset('assets/datatables/js/jquery.dataTables.min.js') !!}"></script>

<script src="{!! asset('assets/validator/validator.js') !!}"></script>


<script src="{!! asset('js/sweetalert2.min.js') !!}"></script>


</body>

</html>
