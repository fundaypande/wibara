@include('layoutPublic.header')
@include('layoutPublic.heading')


@yield('content')


@include('layoutPublic.footer')
